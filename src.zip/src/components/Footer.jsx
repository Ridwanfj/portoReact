import React from "react";
import { Github, Mail, Linkedin } from "lucide-react";

export default function Footer() {
  return (
    <footer className="w-full mt-20 py-10 px-6 md:px-20 text-soft border-t border-white/10 backdrop-blur-sm">
      <div className="max-w-6xl mx-auto flex flex-col md:flex-row justify-between items-center gap-6">

        {/* LEFT — NAME */}
        <h3 className="text-xl font-semibold text-soft/90 tracking-wide">
          Ridwan Fajariansyah
        </h3>

        {/* CENTER — SOCIAL ICONS */}
        <div className="flex items-center gap-6">
          <a
            href="mailto:your-email@gmail.com"
            className="hover:text-accent transition"
          >
            <Mail size={22} />
          </a>

          <a
            href="https://github.com/yourgithub"
            target="_blank"
            className="hover:text-accent transition"
          >
            <Github size={22} />
          </a>

          <a
            href="https://linkedin.com/in/yourlinkedin"
            target="_blank"
            className="hover:text-accent transition"
          >
            <Linkedin size={22} />
          </a>
        </div>

        {/* RIGHT — COPYRIGHT */}
        <p className="text-soft/60 text-sm">
          © {new Date().getFullYear()} All Rights Reserved.
        </p>
      </div>
    </footer>
  );
}
